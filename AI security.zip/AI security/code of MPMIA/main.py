import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
import warnings
warnings.filterwarnings("ignore")
import numpy as np
import torch
from Utils import data_split, data_split_ood, evaluate
from Parser import parameter_parser
from Models import Target_Model, Shadow_Model, Attack_Model
from torch_geometric.data import Data
from Train import train_GNN, test_GNN, train_attack
from sklearn import preprocessing


# 同数据分布半监督GNN成员推断攻击
def MPMIA(args):
    conf = {'Cora': 30, 'CiteSeer': 80, 'PubMed': 500, 'CS': 100, 'Physics': 300, 'Computers': 40, 'Photo': 50}
    parameters = {}
    parameters['num_target_train_per_class'] = conf[args.dataset]
    parameters['num_shadow_train_per_class'] = conf[args.dataset]
    device = torch.device('cuda') if args.cuda else torch.device('cpu')

    # 目标数据集、目标GNN、影子数据集、影子GNN初始化
    target_dataset, shadow_dataset = data_split(args.dataset, parameters)
    target_model = Target_Model(target_dataset.x.shape[1], args.target_hidden_dim,
                                (target_dataset.y.max() + 1).item(),
                                args.target_backbone)
    shadow_model = Shadow_Model(shadow_dataset.x.shape[1], args.shadow_hidden_dim,
                                (shadow_dataset.y.max() + 1).item(),
                                args.shadow_backbone)
    target_optimizer = torch.optim.Adam(target_model.parameters(), lr=args.learning_rate,
                                        weight_decay=args.weight_decay)
    shadow_optimizer = torch.optim.Adam(shadow_model.parameters(), lr=args.learning_rate,
                                        weight_decay=args.weight_decay)
    target_batched = False if args.target_backbone == 'GCN' else True
    shadow_batched = False if args.shadow_backbone == 'GCN' else True
    target_GNN_path = os.path.join('{}_target_{}.pkl'.format(args.dataset, args.target_backbone))
    shadow_GNN_path = os.path.join('{}_shadow_{}.pkl'.format(args.dataset, args.shadow_backbone))

    # 目标GNN影子GNN训练
    if os.path.exists(target_GNN_path):
        target_model.load_state_dict(torch.load('{}'.format(target_GNN_path)))
    else:
        train_GNN(target_model, target_optimizer, target_dataset.x.to(device),
                  target_dataset.y.to(device),
                  target_dataset.edge_index.to(device), target_dataset.target_train_mask,
                  target_dataset.target_val_mask,
                  target_dataset.target_test_mask, args, device, target_batched)
        torch.save(target_model.state_dict(), '{}'.format(target_GNN_path))
    if os.path.exists(shadow_GNN_path):
        shadow_model.load_state_dict(torch.load('{}'.format(shadow_GNN_path)))
    else:
        train_GNN(shadow_model, shadow_optimizer, shadow_dataset.x.to(device),
                  shadow_dataset.y.to(device),
                  shadow_dataset.edge_index.to(device), shadow_dataset.shadow_train_mask,
                  shadow_dataset.shadow_val_mask,
                  shadow_dataset.shadow_test_mask, args, device, shadow_batched)
        torch.save(shadow_model.state_dict(), '{}'.format(shadow_GNN_path))

    rand_edge_index = target_dataset.edge_index
    rand_idx = torch.randperm(rand_edge_index.shape[1])
    rand_edge_index = rand_edge_index[:,rand_idx[:int(rand_idx.shape[0] * args.edge_rate)]]
    target_rand_dataset = Data(x=target_dataset.x, y=target_dataset.y, edge_index=rand_edge_index,
                target_train_mask=target_dataset.target_train_mask, target_val_mask=target_dataset.target_val_mask,
                target_test_mask=target_dataset.target_test_mask)

    # 获取目标数据集在目标GNN上后验概率
    target_post_out1, _ = test_GNN(target_model, target_rand_dataset.x.to(device), target_rand_dataset.y.to(device),
                                   target_rand_dataset.edge_index.to(device),
                                   torch.ones(target_rand_dataset.x.shape[0], dtype=torch.bool), args, device,
                                   target_batched)

    target_post_out2, _ = test_GNN(target_model, target_dataset.x.to(device), target_dataset.y.to(device),
                                   torch.from_numpy(np.array([[], []], dtype=np.int64)).to(device),
                                   torch.ones(target_dataset.x.shape[0], dtype=torch.bool), args, device,
                                   target_batched)

    target_post_out1 = target_post_out1.data
    target_post_out2 = target_post_out2.data


    # 计算KL散度
    target_tmp = torch.kl_div(target_post_out2, target_post_out1, log_target=True)

    minmax_scaler = preprocessing.MinMaxScaler()  # 默认为范围0~1，拷贝操作
    target_tmp = torch.from_numpy(minmax_scaler.fit_transform(target_tmp.detach().numpy()))
    target_post = torch.cat((torch.topk(torch.exp(target_post_out1), target_post_out1.shape[1])[0], target_tmp), dim=1)

    shadow_post_out1, _ = test_GNN(shadow_model, shadow_dataset.x.to(device), shadow_dataset.y.to(device),
                                   shadow_dataset.edge_index.to(device),
                                   torch.ones(shadow_dataset.x.shape[0], dtype=torch.bool), args, device,
                                   shadow_batched)

    shadow_post_out2, _ = test_GNN(shadow_model, shadow_dataset.x.to(device), shadow_dataset.y.to(device),
                                   torch.from_numpy(np.array([[], []], dtype=np.int64)).to(device),
                                   torch.ones(shadow_dataset.x.shape[0], dtype=torch.bool), args, device,
                                   shadow_batched)

    shadow_post_out1 = shadow_post_out1.data
    shadow_post_out2 = shadow_post_out2.data

    # shadow_tmp = (torch.kl_div(shadow_post_out2, shadow_post_out1, log_target=True) + torch.kl_div(shadow_post_out1,
    #                                                                                                shadow_post_out2,
    #                                                                                                log_target=True)) / 2.0
    shadow_tmp = torch.kl_div(shadow_post_out2, shadow_post_out1, log_target=True)
    minmax_scaler = preprocessing.MinMaxScaler()  # 默认为范围0~1，拷贝操作
    shadow_tmp = torch.from_numpy(minmax_scaler.fit_transform(shadow_tmp.detach().numpy()))
    shadow_post = torch.cat((torch.topk(torch.exp(shadow_post_out1), shadow_post_out1.shape[1])[0], shadow_tmp), dim=1)


    scale = int(min([shadow_dataset.shadow_train_mask.sum(),
                     shadow_dataset.shadow_val_mask.sum(),
                     shadow_dataset.shadow_test_mask.sum()]))

    ratio = 0.8

    # 攻击模型数据集构造
    if args.target_dataset == args.shadow_dataset:
        attack_train_x = torch.cat((torch.cat((shadow_post[shadow_dataset.shadow_train_mask][:int(scale * ratio)],
                                               shadow_post[shadow_dataset.shadow_val_mask][:int(scale * ratio)]),
                                              dim=0)
                                    , shadow_post[shadow_dataset.shadow_test_mask][:int(scale * ratio)]), dim=0)
        attack_val_x = torch.cat(
            (torch.cat((shadow_post[shadow_dataset.shadow_train_mask][int(scale * ratio): scale],
                        shadow_post[shadow_dataset.shadow_val_mask][int(scale * ratio): scale]), dim=0)
             , shadow_post[shadow_dataset.shadow_test_mask][int(scale * ratio): scale]), dim=0)
        attack_test_x = torch.cat((torch.cat((target_post[target_dataset.target_train_mask][:scale],
                                              target_post[target_dataset.target_val_mask][:scale]), dim=0)
                                   , target_post[target_dataset.target_test_mask][:scale]), dim=0)

    else:
        attack_train_x = torch.cat((torch.cat((shadow_post[shadow_dataset.shadow_train_mask][:int(scale * ratio)],
                                               shadow_post[shadow_dataset.shadow_val_mask][:int(scale * ratio)]),
                                              dim=0)
                                    , shadow_post[shadow_dataset.shadow_test_mask][:int(scale * ratio)]), dim=0)
        attack_train_x = torch.topk(attack_train_x, args.topk)[0]
        attack_val_x = torch.cat(
            (torch.cat((shadow_post[shadow_dataset.shadow_train_mask][int(scale * ratio):scale],
                        shadow_post[shadow_dataset.shadow_val_mask][int(scale * ratio):scale]), dim=0)
             , shadow_post[shadow_dataset.shadow_test_mask][int(scale * ratio):scale]), dim=0)
        attack_val_x = torch.topk(attack_val_x, args.topk)[0]
        attack_test_x = torch.cat((torch.cat((target_post[target_dataset.target_train_mask][:scale],
                                              target_post[target_dataset.target_val_mask][:scale]), dim=0)
                                   , target_post[target_dataset.target_test_mask][:scale]), dim=0)

    # 半监督三分类成员推断攻击
    attack_train_y = torch.zeros(attack_train_x.shape[0], dtype=torch.long)
    attack_train_y[:int(attack_train_x.shape[0] / 3)] = 0
    attack_train_y[int(attack_train_x.shape[0] / 3):2 * int(attack_train_x.shape[0] / 3)] = 1
    attack_train_y[2 * int(attack_train_x.shape[0] / 3):] = 2

    attack_val_y = torch.zeros(attack_val_x.shape[0], dtype=torch.long)
    attack_val_y[:int(attack_val_x.shape[0] / 3)] = 0
    attack_val_y[int(attack_val_x.shape[0] / 3):2 * int(attack_val_x.shape[0] / 3)] = 1
    attack_val_y[2 * int(attack_val_x.shape[0] / 3):] = 2

    attack_test_y = torch.zeros(attack_test_x.shape[0], dtype=torch.long)
    attack_test_y[:int(attack_test_x.shape[0] / 3)] = 0
    attack_test_y[int(attack_test_x.shape[0] / 3):2 * int(attack_test_x.shape[0] / 3)] = 1
    attack_test_y[2 * int(attack_test_x.shape[0] / 3):] = 2


    attack_model = Attack_Model(attack_train_x.shape[1], args.attack_hidden_dim, 3)
    attack_optimizer = torch.optim.Adam(attack_model.parameters(), lr=args.learning_rate )

    train_attack(attack_model, attack_optimizer,
                                        attack_train_x, attack_train_y, attack_val_x,
                                        attack_val_y, attack_test_x, attack_test_y, args, device)




dataset = ['Cora', 'PubMed', 'CS', 'Physics', 'Computers', 'Photo']
# dataset = ['Photo']
# dataset = ['PubMed','CS', 'Physics', 'Photo']
dataset = ['Computers', 'Photo']
# dataset = ['Computers']
seed = {'Cora': 42, 'PubMed': 42, 'CS': 42, 'Physics': 42, 'Computers': 42, 'Photo': 42}


# 不同数据分布半监督GNN成员推断攻击
def MPMIA_cross_dataset():
    args = parameter_parser()
    conf = {'Cora': 30, 'CiteSeer': 80, 'PubMed': 500, 'CS': 100, 'Physics': 300, 'Computers': 40, 'Photo': 50}
    parameters = {}
    parameters['num_target_train_per_class'] = conf[args.target_dataset]
    parameters['num_shadow_train_per_class'] = conf[args.shadow_dataset]
    device = torch.device('cuda') if args.cuda else torch.device('cpu')
    target_dataset, shadow_dataset = data_split_ood(args.target_dataset, args.shadow_dataset, parameters)

    target_model = Target_Model(target_dataset.x.shape[1], args.target_hidden_dim,
                                (target_dataset.y.max() + 1).item(),
                                args.target_backbone)
    shadow_model = Shadow_Model(shadow_dataset.x.shape[1], args.shadow_hidden_dim,
                                (shadow_dataset.y.max() + 1).item(),
                                args.shadow_backbone)

    target_optimizer = torch.optim.Adam(target_model.parameters(), lr=args.learning_rate,
                                        weight_decay=args.weight_decay)
    shadow_optimizer = torch.optim.Adam(shadow_model.parameters(), lr=args.learning_rate,
                                        weight_decay=args.weight_decay)

    target_batched = False if args.target_backbone == 'GCN' else True
    shadow_batched = False if args.shadow_backbone == 'GCN' else True
    target_GNN_path = os.path.join('{}_target_{}.pkl'.format(args.target_dataset, args.target_backbone))
    shadow_GNN_path = os.path.join('{}_shadow_{}.pkl'.format(args.shadow_dataset, args.shadow_backbone))
    if os.path.exists(target_GNN_path):
        target_model.load_state_dict(torch.load('{}'.format(target_GNN_path)))
    else:
        train_GNN(target_model, target_optimizer, target_dataset.x.to(device),
                  target_dataset.y.to(device),
                  target_dataset.edge_index.to(device), target_dataset.target_train_mask,
                  target_dataset.target_val_mask,
                  target_dataset.target_test_mask, args, device, target_batched)
        torch.save(target_model.state_dict(), '{}'.format(target_GNN_path))
    if os.path.exists(shadow_GNN_path):
        shadow_model.load_state_dict(torch.load('{}'.format(shadow_GNN_path)))
    else:
        train_GNN(shadow_model, shadow_optimizer, shadow_dataset.x.to(device),
                  shadow_dataset.y.to(device),
                  shadow_dataset.edge_index.to(device), shadow_dataset.shadow_train_mask,
                  shadow_dataset.shadow_val_mask,
                  shadow_dataset.shadow_test_mask, args, device, shadow_batched)
        torch.save(shadow_model.state_dict(), '{}'.format(shadow_GNN_path))

    target_post_out1, _ = test_GNN(target_model, target_dataset.x.to(device), target_dataset.y.to(device),
                                   target_dataset.edge_index.to(device),
                                   torch.ones(target_dataset.x.shape[0], dtype=torch.bool), args, device,
                                   target_batched)

    target_post_out2, _ = test_GNN(target_model, target_dataset.x.to(device), target_dataset.y.to(device),
                                   torch.from_numpy(np.array([[], []], dtype=np.int64)).to(device),
                                   torch.ones(target_dataset.x.shape[0], dtype=torch.bool), args, device,
                                   target_batched)

    target_post_out1 = target_post_out1.data
    target_post_out2 = target_post_out2.data

    # target_tmp = (torch.kl_div(target_post_out2, target_post_out1, log_target=True) + torch.kl_div(target_post_out1,
    #                                                                                                target_post_out2,
    #                                                                                                log_target=True)) / 2.0
    target_tmp = torch.topk(torch.kl_div(target_post_out2, target_post_out1, log_target=True), args.topk)[0]

    minmax_scaler = preprocessing.MinMaxScaler()  # 默认为范围0~1，拷贝操作
    target_tmp = torch.from_numpy(minmax_scaler.fit_transform(target_tmp.detach().numpy()))

    target_post = torch.cat((torch.topk(torch.exp(target_post_out1), args.topk)[0], target_tmp), dim=1)

    shadow_post_out1, _ = test_GNN(shadow_model, shadow_dataset.x.to(device), shadow_dataset.y.to(device),
                                   shadow_dataset.edge_index.to(device),
                                   torch.ones(shadow_dataset.x.shape[0], dtype=torch.bool), args, device,
                                   shadow_batched)

    shadow_post_out2, _ = test_GNN(shadow_model, shadow_dataset.x.to(device), shadow_dataset.y.to(device),
                                   torch.from_numpy(np.array([[], []], dtype=np.int64)).to(device),
                                   torch.ones(shadow_dataset.x.shape[0], dtype=torch.bool), args, device,
                                   shadow_batched)

    shadow_post_out1 = shadow_post_out1.data
    shadow_post_out2 = shadow_post_out2.data


    shadow_tmp = torch.topk(torch.kl_div(shadow_post_out2, shadow_post_out1, log_target=True), args.topk)[0]

    minmax_scaler = preprocessing.MinMaxScaler()  # 默认为范围0~1，拷贝操作
    shadow_tmp = torch.from_numpy(minmax_scaler.fit_transform(shadow_tmp.detach().numpy()))

    shadow_post = torch.cat((torch.topk(torch.exp(shadow_post_out1), args.topk)[0], shadow_tmp), dim=1)

    scale = int(min([shadow_dataset.shadow_train_mask.sum(),
                     shadow_dataset.shadow_val_mask.sum(),
                     shadow_dataset.shadow_test_mask.sum()]))

    ratio = 0.8
    device = torch.device('cuda') if args.cuda else torch.device('cpu')


    attack_train_x = torch.cat((torch.cat((shadow_post[shadow_dataset.shadow_train_mask][:int(scale * ratio)],
                                           shadow_post[shadow_dataset.shadow_val_mask][:int(scale * ratio)]),
                                          dim=0)
                                , shadow_post[shadow_dataset.shadow_test_mask][:int(scale * ratio)]), dim=0)

    attack_val_x = torch.cat(
        (torch.cat((shadow_post[shadow_dataset.shadow_train_mask][int(scale * ratio):scale],
                    shadow_post[shadow_dataset.shadow_val_mask][int(scale * ratio):scale]), dim=0)
         , shadow_post[shadow_dataset.shadow_test_mask][int(scale * ratio):scale]), dim=0)

    attack_test_x = torch.cat((torch.cat((target_post[target_dataset.target_train_mask][:scale],
                                          target_post[target_dataset.target_val_mask][:scale]), dim=0)
                               , target_post[target_dataset.target_test_mask][:scale]), dim=0)


    attack_train_y = torch.zeros(attack_train_x.shape[0], dtype=torch.long)
    attack_train_y[:int(attack_train_x.shape[0] / 3)] = 0
    attack_train_y[int(attack_train_x.shape[0] / 3):2 * int(attack_train_x.shape[0] / 3)] = 1
    attack_train_y[2 * int(attack_train_x.shape[0] / 3):] = 2

    attack_val_y = torch.zeros(attack_val_x.shape[0], dtype=torch.long)
    attack_val_y[:int(attack_val_x.shape[0] / 3)] = 0
    attack_val_y[int(attack_val_x.shape[0] / 3):2 * int(attack_val_x.shape[0] / 3)] = 1
    attack_val_y[2 * int(attack_val_x.shape[0] / 3):] = 2

    attack_test_y = torch.zeros(attack_test_x.shape[0], dtype=torch.long)
    attack_test_y[:int(attack_test_x.shape[0] / 3)] = 0
    attack_test_y[int(attack_test_x.shape[0] / 3):2 * int(attack_test_x.shape[0] / 3)] = 1
    attack_test_y[2 * int(attack_test_x.shape[0] / 3):] = 2


    attack_model = Attack_Model(attack_train_x.shape[1], args.attack_hidden_dim, 3)
    attack_optimizer = torch.optim.Adam(attack_model.parameters(), lr=args.learning_rate)

    train_attack(attack_model, attack_optimizer,
                                  attack_train_x, attack_train_y, attack_val_x,
                                  attack_val_y, attack_test_x, attack_test_y, args, device)


torch.cuda.manual_seed(42)
torch.manual_seed(42)
np.random.seed(42)
args = parameter_parser()
if args.target_dataset == args.shadow_dataset:
    MPMIA(args)
else:
    MPMIA_cross_dataset(args)
