from torch_geometric.datasets import Planetoid, Coauthor, Amazon
import torch
import numpy as np
from torch_geometric.loader import NeighborSampler
from torch_geometric.data import Data
from sklearn.metrics import f1_score

# large-margin softmax损失函数， reg_lambda为超参
class LargeMarginInSoftmaxLoss(torch.nn.CrossEntropyLoss):

    def __init__(self, reg_lambda=0.3, deg_logit=None,
                 weight=None, size_average=None, ignore_index=-100, reduce=None, reduction='mean'):
        super(LargeMarginInSoftmaxLoss, self).__init__(weight=weight, size_average=size_average,
                                                       ignore_index=ignore_index, reduce=reduce, reduction=reduction)
        self.reg_lambda = reg_lambda
        self.deg_logit = deg_logit

    def forward(self, input, target):
        N = input.size(0)  # number of samples
        C = input.size(1)  # number of classes
        Mask = torch.zeros_like(input, requires_grad=False)
        Mask[range(N), target] = 1

        if self.deg_logit is not None:
            input = input - self.deg_logit * Mask

        loss = torch.nn.functional.cross_entropy(input, target, weight=self.weight,
                               ignore_index=self.ignore_index, reduction=self.reduction)

        X = input - 1.e6 * Mask  # [N x C], excluding the target class
        reg = 0.5 * ((torch.nn.functional.softmax(X, dim=1) - 1.0 / (C - 1)) * torch.nn.functional.log_softmax(X, dim=1) * (1.0 - Mask)).sum(dim=1)
        if self.reduction == 'sum':
            reg = reg.sum()
        elif self.reduction == 'mean':
            reg = reg.mean()
        elif self.reduction == 'none':
            reg = reg

        return loss + self.reg_lambda * reg


# 同数据分布数据切分，切分为目标数据集与影子数据集
def data_split(dataset_name, parameters):
    if dataset_name == 'Cora' or dataset_name == 'PubMed':
        dataset = Planetoid(root='./data', name='{}'.format(dataset_name))[0]
    elif dataset_name == 'CS' or dataset_name == 'Physics':
        dataset = Coauthor(root='./data', name='{}'.format(dataset_name))[0]
    elif dataset_name == 'Computers' or dataset_name == 'Photo':
        dataset = Amazon(root='./data', name='{}'.format(dataset_name))[0]
    num_classes = dataset.y.max() + 1

    t = int(dataset.x.shape[0] / 2)
    target_edge_index = [[], []]
    shadow_edge_index = [[], []]
    for i in range(dataset.edge_index.shape[1]):
        if dataset.edge_index[0, i] < t and dataset.edge_index[1, i] < t:
            target_edge_index[0].append(dataset.edge_index[0, i])
            target_edge_index[1].append(dataset.edge_index[1, i])
        elif dataset.edge_index[0, i] >= t and dataset.edge_index[1, i] >= t:
            shadow_edge_index[0].append(dataset.edge_index[0, i] - t)
            shadow_edge_index[1].append(dataset.edge_index[1, i] - t)
    target_edge_index = torch.from_numpy(np.array(target_edge_index))
    shadow_edge_index = torch.from_numpy(np.array(shadow_edge_index))
    target_dataset = Data(x=dataset.x[:t, :], y=dataset.y[:t], edge_index=target_edge_index)
    shadow_dataset = Data(x=dataset.x[t:, :], y=dataset.y[t:], edge_index=shadow_edge_index)

    def get_train_idx(data_set, mode='target'):
        train_idx = []
        for c in range(num_classes):
            idx = (data_set.y == c).nonzero().view(-1).numpy()
            rand_train_idx = idx
            if mode == 'target':
                sample_train_id = rand_train_idx[:parameters['num_target_train_per_class']]
            else:
                sample_train_id = rand_train_idx[:parameters['num_shadow_train_per_class']]
            train_idx.extend(sample_train_id)

        return train_idx

    target_train_idx = get_train_idx(target_dataset, 'target')
    shadow_train_idx = get_train_idx(shadow_dataset, 'shadow')

    target_train_mask = torch.zeros(target_dataset.x.shape[0], dtype=torch.bool)
    shadow_train_mask = torch.zeros(shadow_dataset.x.shape[0], dtype=torch.bool)
    target_train_mask[target_train_idx] = True
    shadow_train_mask[shadow_train_idx] = True

    def get_val_test(dataset, train_idx, train_mask):
        ns = NeighborSampler(dataset.edge_index, node_idx=train_mask,
                             sizes=[-1, -1], num_nodes=dataset.x.shape[0], batch_size=train_mask.sum().item())

        for _, n_id, _ in ns:
            hops = n_id.tolist()

        val_idx = hops[len(train_idx):]

        test_idx = [x for x in range(dataset.x.shape[0]) if x not in set(train_idx) and x not in set(val_idx)]

        val_mask = torch.zeros(dataset.x.shape[0], dtype=torch.bool)
        test_mask = torch.zeros(dataset.x.shape[0], dtype=torch.bool)

        val_mask[val_idx] = True
        test_mask[test_idx] = True
        return val_mask, test_mask

    target_val_mask, target_test_mask = get_val_test(target_dataset, target_train_idx, target_train_mask)
    shadow_val_mask, shadow_test_mask = get_val_test(shadow_dataset, shadow_train_idx, shadow_train_mask)

    return Data(x=target_dataset.x, y=target_dataset.y, edge_index=target_dataset.edge_index,
                target_train_mask=target_train_mask, target_val_mask=target_val_mask,
                target_test_mask=target_test_mask), \
           Data(x=shadow_dataset.x, y=shadow_dataset.y, edge_index=shadow_dataset.edge_index,
                shadow_train_mask=shadow_train_mask, shadow_val_mask=shadow_val_mask,
                shadow_test_mask=shadow_test_mask)

# 不同数据分布数据切分，切分为目标数据集与影子数据集
def data_split_ood(target_dataset_name, shadow_dataset_name, parameters):


    def random_select(dataset, mode='target'):
        num_classes = dataset.y.max() + 1
        train_idx = []
        for c in range(num_classes):
            idx = (dataset.y == c).nonzero().view(-1).numpy()
            rand_train_idx = idx
            if mode == 'target':
                sample_train_id = rand_train_idx[:parameters['num_target_train_per_class']]
            else:
                sample_train_id = rand_train_idx[:parameters['num_shadow_train_per_class']]

            train_idx.extend(sample_train_id)

        train_mask = torch.zeros(dataset.x.shape[0], dtype=torch.bool)
        train_mask[train_idx] = True

        ns = NeighborSampler(dataset.edge_index, node_idx=train_mask,
                             sizes=[-1, -1], num_nodes=dataset.x.shape[0], batch_size=train_mask.sum().item())

        for _, n_id, _ in ns:
            hops = n_id.tolist()

        val_idx = hops[len(train_idx):]

        test_idx = [x for x in range(dataset.x.shape[0]) if x not in set(train_idx) and x not in set(val_idx)]

        val_mask = torch.zeros(dataset.x.shape[0], dtype=torch.bool)
        test_mask = torch.zeros(dataset.x.shape[0], dtype=torch.bool)

        val_mask[val_idx] = True
        test_mask[test_idx] = True
        return train_mask, val_mask, test_mask

    if target_dataset_name == 'Cora' or target_dataset_name == 'PubMed':
        target_dataset = Planetoid(root='./data', name='{}'.format(target_dataset_name))[0]
    elif target_dataset_name == 'CS' or target_dataset_name == 'Physics':
        target_dataset = Coauthor(root='./data', name='{}'.format(target_dataset_name))[0]
    elif target_dataset_name == 'Computers' or target_dataset_name == 'Photo':
        target_dataset = Amazon(root='./data', name='{}'.format(target_dataset_name))[0]

    target_train_mask, target_val_mask, target_test_mask = random_select(target_dataset, 'target')

    if shadow_dataset_name == 'Cora' or shadow_dataset_name == 'PubMed':
        shadow_dataset = Planetoid(root='./data', name='{}'.format(shadow_dataset_name))[0]
    elif shadow_dataset_name == 'CS' or shadow_dataset_name == 'Physics':
        shadow_dataset = Coauthor(root='./data', name='{}'.format(shadow_dataset_name))[0]
    elif shadow_dataset_name == 'Computers' or shadow_dataset_name == 'Photo':
        shadow_dataset = Amazon(root='./data', name='{}'.format(shadow_dataset_name))[0]

    shadow_train_mask, shadow_val_mask, shadow_test_mask = random_select(shadow_dataset, 'shadow')

    return Data(x=target_dataset.x, y=target_dataset.y, edge_index=target_dataset.edge_index,
                target_train_mask=target_train_mask, target_val_mask=target_val_mask,
                target_test_mask=target_test_mask), \
           Data(x=shadow_dataset.x, y=shadow_dataset.y, edge_index=shadow_dataset.edge_index,
                shadow_train_mask=shadow_train_mask, shadow_val_mask=shadow_val_mask, shadow_test_mask=shadow_test_mask)


# 模型性评估能
def evaluate(label, y_pred):
    acc = y_pred.eq(label).sum().item() / y_pred.shape[0]
    f1_micro = f1_score(label, y_pred, average = 'micro')
    f1_macro = f1_score(label, y_pred, average = 'macro')
    return acc, f1_micro, f1_macro
