import torch
from torch_geometric.nn import GCNConv, GATConv

# 目标GNN
class Target_Model(torch.nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, backbone = 'GCN'):
        super().__init__()
        self.layers = torch.nn.ModuleList()
        self.num_layers = len(hidden_dim) + 1
        self.backbone = backbone
        if backbone == 'GCN':
            self.layers.append(GCNConv(input_dim, hidden_dim[0], normalize = True))
            for i in range(len(hidden_dim) - 1):
                self.layers.append(GCNConv(hidden_dim[i], hidden_dim[i + 1], normalize = True))
            self.layers.append(GCNConv(hidden_dim[-1], output_dim, normalize = True))
        if backbone == 'GAT':
            self.layers.append(GATConv(input_dim, hidden_dim[0], heads = 8))
            for i in range(len(hidden_dim) - 1):
                self.layers.append(GATConv(hidden_dim[i] * 8, hidden_dim[i + 1], heads = 8))
            self.layers.append(GATConv(hidden_dim[-1] * 8, output_dim, heads = 1))


    def forward(self, x, adjs, dropout_rate = 0.5):
        if self.backbone == 'GAT':
            for i, (edge_index, _, size) in enumerate(adjs):
                x_target = x[:size[1]]
                x = self.layers[i]((x, x_target), edge_index)
                if i != self.num_layers - 1:
                    x = torch.nn.functional.relu(x)
                    x = torch.nn.functional.dropout(x, p = dropout_rate)
        else:
            for i in range(self.num_layers):
                x = self.layers[i](x, adjs)
                if i != self.num_layers - 1:
                    x = torch.nn.functional.relu(x)
                    x = torch.nn.functional.dropout(x, p=dropout_rate)
        return torch.nn.functional.log_softmax(x, dim = 1)

# 影子GNN

class Shadow_Model(torch.nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, backbone = 'GCN'):
        super().__init__()
        self.layers = torch.nn.ModuleList()
        self.num_layers = len(hidden_dim) + 1
        self.backbone = backbone
        if backbone == 'GCN':
            self.layers.append(GCNConv(input_dim, hidden_dim[0], normalize = True))
            for i in range(len(hidden_dim) - 1):
                self.layers.append(GCNConv(hidden_dim[i], hidden_dim[i + 1], normalize = True))
            self.layers.append(GCNConv(hidden_dim[-1], output_dim, normalize = True))
        if backbone == 'GAT':
            self.layers.append(GATConv(input_dim, hidden_dim[0], heads = 8))
            for i in range(len(hidden_dim) - 1):
                self.layers.append(GATConv(hidden_dim[i] * 8, hidden_dim[i + 1], heads = 8))
            self.layers.append(GATConv(hidden_dim[-1] * 8, output_dim, heads = 1))

    def forward(self, x, adjs, dropout_rate = 0.5):
        if self.backbone == 'GAT':
            for i, (edge_index, _, size) in enumerate(adjs):
                x_target = x[:size[1]]
                x = self.layers[i]((x, x_target), edge_index)
                if i != self.num_layers - 1:
                    x = torch.nn.functional.relu(x)
                    x = torch.nn.functional.dropout(x, p = dropout_rate)
        else:
            for i in range(self.num_layers):
                x = self.layers[i](x, adjs)
                if i != self.num_layers - 1:
                    x = torch.nn.functional.relu(x)
                    x = torch.nn.functional.dropout(x, p=dropout_rate)

        return torch.nn.functional.log_softmax(x, dim = 1)


class Attack_Model(torch.nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super().__init__()
        self.layers = torch.nn.ModuleList()
        self.layers.append(torch.nn.Linear(input_dim, hidden_dim[0]))
        for i in range(len(hidden_dim) - 1):
            self.layers.append(torch.nn.Linear(hidden_dim[i], hidden_dim[i + 1]))
        self.layers.append(torch.nn.Linear(hidden_dim[-1], output_dim))
        self.softmax = torch.nn.LogSoftmax(dim = 1)

    def forward(self, x):
        h = x
        for layer in self.layers[:-1]:
            h = torch.nn.functional.relu(torch.nn.functional.dropout(layer(h), p = 0.))
        h = self.layers[-1](h)
        # h = self.softmax(self.layers[-1](h))
        return torch.nn.functional.softmax(h, dim = 1)
