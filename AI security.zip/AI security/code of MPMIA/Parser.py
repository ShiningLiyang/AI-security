import argparse

def parameter_parser():
    parser = argparse.ArgumentParser(description="Run .")
    parser.add_argument('--target_dataset',
                        type=str,
                        default='Cora',
                        help='dataset name.')
    parser.add_argument('--shadow_dataset',
                        type=str,
                        default='Cora',
                        help='dataset name.')
    if parser.parse_args().target_dataset == parser.parse_args().shadow_dataset:
        parser.add_argument('--dataset',
                            type=str,
                            default='Cora',
                            help='dataset name.')
        parser.add_argument('--topk',
                            type=int,
                            default= 3,
                            help='topk.')
        parser.add_argument('--ood',
                            type=bool,
                            default=False)
    else:
        parser.add_argument('--ood',
                            type=bool,
                            default=True)

    parser.add_argument("--epochs",
                        type=int,
                        default = 500,
                        help="Number of training epochs.")

    parser.add_argument("--dropout",
                        type=float,
                        default= 0.,
                        help="Dropout parameter.")

    parser.add_argument("--learning-rate",
                        type=float,
                        default= 0.001,
                        help="Learning rate.")

    parser.add_argument("--weight-decay",
                        type=float,
                        default= 5e-4,
                        help="Weight decay.")

    parser.add_argument('--batch-size',
                        type=int,
                        default = 512,
                        help='batchsize for train')

    parser.add_argument('--num_target_train_per_class',
                        type=int,
                        default = 20,
                        help='number of target train nodes per_class.')
    parser.add_argument('--num_shadow_train_per_class',
                        type=int,
                        default = 20,
                        help='number of shadow train nodes per_class.')

    parser.add_argument('--cuda',
                        type=bool,
                        default=True,
                        help='cuda settings.')

    parser.add_argument('--target_backbone',
                        type=str,
                        default='GCN',
                        help='Backbone of Target Model.')
    parser.add_argument('--shadow_backbone',
                        type=str,
                        default='GCN',
                        help='Backbone of Shadow Model.')

    parser.add_argument('--target_hidden_dim',
                        type=list,
                        default=[16],
                        help='Hidden dimensions of Target Model.')
    parser.add_argument('--shadow_hidden_dim',
                        type=list,
                        default=[16],
                        help='Hidden dimensions of Shadow Model.')
    parser.add_argument('--attack_hidden_dim',
                        type=list,
                        default=[32],
                        help='Hidden dimensions of Attack Model.')

    parser.add_argument("--reg",
                        type=float,
                        default = 1.0,
                        help="Hypeparameter for LSL.")

    parser.add_argument('--edge_rate',
                        type=float,
                        default=1.,
                        help='Ddge rate remained.')
    return parser.parse_args()
