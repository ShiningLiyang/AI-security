from torch_geometric.loader import NeighborSampler
import torch
from sklearn.metrics import precision_score, recall_score, f1_score
from Utils import evaluate, LargeMarginInSoftmaxLoss



# 目标GNN与影子GNN的训练
def train_GNN(model, optimizer, x, y, edge_index, train_mask, val_mask, test_mask, args, device, batched = False):
    max_acc = -1
    if batched == True:
        model.to(device)

        train_loader = NeighborSampler(edge_index, node_idx = train_mask,
                                       sizes=[-1, -1], num_nodes = x.shape[0], batch_size = args.batch_size, shuffle = True)
        for i in range(args.epochs):
            model.train()
            for j, (batch_size, n_id, adjs) in enumerate(train_loader):
                adjs = [adj.to(device) for adj in adjs]
                optimizer.zero_grad()
                out = model(x[n_id].to(device), adjs, args.dropout)
                loss = torch.nn.functional.nll_loss(out, y[n_id[:batch_size]].to(device))
                loss.backward()
                optimizer.step()
                # print('Train loss:',loss)
                # acc, f1_mi, f1_ma = evaluate(y[n_id[:batch_size]].cpu(), out.cpu().argmax(dim = -1))
                # print('Train acc:',acc,",'|Train f1_mi:", f1_mi, '|Train f1_ma:', f1_ma)
            _, acc = test_GNN(model, x, y, edge_index, val_mask, args, device, True)
            if acc > max_acc:
                max_acc = acc
                # torch.save(model.state_dict(), 'best_model.pkl')
                # out, acc = test_GNN(model, x, y, edge_index, test_mask, args, device, True)
        # model.load_state_dict(torch.load('best_model.pkl'))
        out, acc = test_GNN(model, x, y, edge_index, test_mask, args, device, True)
    else:
        model.to(device)
        for i in range(args.epochs):
            model.train()
            optimizer.zero_grad()
            out = model(x, edge_index, args.dropout)
            loss = torch.nn.functional.nll_loss(out[train_mask], y[train_mask])

            loss.backward()
            optimizer.step()
            _, acc = test_GNN(model, x, y, edge_index, val_mask, args, device, False)
            if acc > max_acc:
                max_acc = acc
                # torch.save(model.state_dict(), 'best_model.pkl')
                # out, acc = test_GNN(model, x, y, edge_index, test_mask, args, device, False)
        # model.load_state_dict(torch.load('best_model.pkl'))
        out, acc = test_GNN(model, x, y, edge_index, test_mask, args, device, False)
    # print('loss:',loss)
    print('Test acc:', acc)
    return out


# 目标GNN与影子GNN的测试
def test_GNN(model, x, y, edge_index, test_mask, args, device, batched = False):
    if batched == True:
        model.to(device)
        model.eval()
        test_loader = NeighborSampler(edge_index, node_idx=test_mask,
                                      sizes=[-1, -1], num_nodes=x.shape[0], batch_size=args.batch_size, shuffle=False)
        all_out = []
        all_post = []
        all_loss = []
        for j, (batch_size, n_id, adjs) in enumerate(test_loader):
            adjs = [adj.to(device) for adj in adjs]
            out = model(x[n_id].to(device), adjs, args.dropout)
            loss = torch.nn.functional.nll_loss(out, y[n_id[:batch_size]].to(device))
            all_out.append(out.cpu().argmax(dim=-1))
            all_post.append(out.cpu())
            all_loss.append(loss)

        all_out = torch.cat(all_out, dim=0)
        all_post = torch.cat(all_post, dim=0)
        acc, f1_mi, f1_ma = evaluate(y[test_mask].cpu(), all_out.cpu())
        # print('Test acc:',acc,",'|Test f1_mi:", f1_mi, '|Test f1_ma:', f1_ma)
        return all_post, acc
    else:
        model.to(device)
        model.eval()
        out = model(x, edge_index)
        # print('Test loss:',loss)
        acc, f1_mi, f1_ma = evaluate(y[test_mask].cpu(), out[test_mask].cpu().argmax(dim=-1))
        out = out.cpu()
        # print('Test acc:',acc,",'|Test f1_mi:", f1_mi, '|Test_f1_ma:', f1_ma)
        return out, acc


# 攻击模型训练
def train_attack(model, optimizer, x, y, val_x, val_y, test_x, test_y, args, device):
    model.to(device)
    max_acc = 0
    accs = []
    loss_func = LargeMarginInSoftmaxLoss(reg_lambda = args.reg, deg_logit = True)
    attack_train_data = torch.utils.data.TensorDataset(x, y)
    attack_train_loader = torch.utils.data.DataLoader(attack_train_data, batch_size = args.batch_size, shuffle = True)
    for i in range(args.epochs):
        model.train()
        for j, (batch_x, batch_y) in enumerate(attack_train_loader):
            optimizer.zero_grad()
            out = model(batch_x.to(device))
            loss = loss_func(out, batch_y.to(device))
            loss.backward()
            optimizer.step()
            # print('cls_loss:',loss)
            # print('Train attack loss:',loss)
            # precision = precision_score(batch_y, out.cpu().data.argmax(dim = -1))
            # recall = recall_score(batch_y, out.cpu().data.argmax(dim = -1))
            # acc, _, _ = evaluate(batch_y, out.cpu().argmax(dim = -1))
            # print('Train attack precision:', precision, '|Train attack recall:', recall, '|Train attack acc:',acc)


        _, acc = test_attack(model, val_x, val_y, args, device)
        accs.append(acc)
        if acc[9] > max_acc:
            max_acc = acc[9]
            # torch.save(model.state_dict(), 'best_model.pkl')
            all_post, Acc = test_attack(model, test_x, test_y, args, device, True)
    return all_post, Acc


# 攻击模型测试
def test_attack(model, x, y, args, device):
    model.to(device)
    attack_test_data = torch.utils.data.TensorDataset(x, y)
    attack_test_loader = torch.utils.data.DataLoader(attack_test_data, batch_size = args.batch_size, shuffle = False)
    all_out = []
    all_post = []
    model.eval()
    for batch_x, batch_y in attack_test_loader:
        out = model(batch_x.to(device))
        all_out.append(out.cpu().argmax(dim = -1))
        all_post.append(out.cpu())

    all_out = torch.cat(all_out, dim = 0)
    all_post = torch.cat(all_post, dim = 0)
    precision = precision_score(y, all_out, labels = [0,1,2], average=None)
    recall = recall_score(y, all_out, labels =[0,1,2], average=None)
    f1 = f1_score(y, all_out, labels=[0, 1, 2], average=None)
    acc, f1_mi, f1_ma = evaluate(y, all_out)
    result = []
    result.extend(precision)
    result.extend(recall)
    result.extend(f1)
    result.append(acc)
    result.append(f1_ma)




    return all_post.data, result
