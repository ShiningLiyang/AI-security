import torch
from torch_geometric.loader import NeighborSampler
from Utils import evaluate
from sklearn import metrics

# 训练GDA
def train_MIA_GAE(model, train_data, val_data, data, args):
    model.to(args.device)
    optimizer = torch.optim.Adam(model.parameters(), lr = args.MIA_GAE_lr)

    for epoch in range(args.MIA_GAE_epochs):
        model.train()
        optimizer.zero_grad()

        # 空间统一
        loss_1 = model.recon_loss(train_data.x.to(args.device), train_data.edge_index.to(args.device),
                                  train_data.mp_edge_index.to(args.device))
        perturbed_data = model.perturbed_graph(train_data, 0.1)

        # 空间对齐
        loss_2 = model.infoNCE_loss(model.encode(train_data.x.to(args.device), train_data.mp_edge_index.to(args.device)),
                               model.encode(perturbed_data.x.to(args.device),
                                            perturbed_data.mp_edge_index.to(args.device)))
        loss = loss_1 + loss_2
        loss.backward()
        optimizer.step()
        if epoch % 2 == 0:
            model.eval()
            z = model.encode(val_data.x.to(args.device), val_data.mp_edge_index.to(args.device))
            graph_recon_loss = model.graph_test(z, val_data.edge_index.to(args.device), val_data.mp_edge_index.to(args.device))
            feats_recon_loss = model.feats_test(z[val_data.infer_mask], val_data.x[val_data.infer_mask].to(args.device))
            print(graph_recon_loss)
            print(feats_recon_loss)

# 训练目标GNN和影子GNN
def train_GNN(model, train_data, val_data, test_data, args, mode = 'target'):
    if mode == 'target':
        optimizer = torch.optim.Adam(model.parameters(), lr = args.target_GNN_lr, weight_decay=5e-4)
    else:
        optimizer = torch.optim.Adam(model.parameters(), lr=args.shadow_GNN_lr, weight_decay=5e-4)
    max_acc = -1
    if args.GNN_batched == True:
        loader = NeighborSampler(edge_index = train_data.mp_edge_index, node_idx = torch.ones(train_data.x.shape[0], dtype = torch.bool),
                                 sizes = [-1, -1], num_nodes = train_data.x.shape[0], batch_size = args.batch_size, shuffle = True)
        for i in range(args.GNN_epochs):
            model.train()
            for j, (batch_size, n_id, adjs) in enumerate(loader):
                adjs = [adj.to(args.device) for adj in adjs]
                optimizer.zero_grad()
                out = model(train_data.x[n_id].to(args.device), adjs, args)
                loss = torch.nn.functional.cross_entropy(out, train_data.y[n_id[:batch_size]].to(args.device))
                loss.backward()
                optimizer.step()
            _, acc = test_GNN(model, val_data, args)
            if acc > max_acc:
                max_acc = acc
                if mode == 'target':
                    torch.save(model.state_dict(), 'target_' + args.target_dataset_name + '_' + args.target_backbone + '_' + str(
                        args.target_num_per_class) + 'best_model.pkl')
                else:
                    torch.save(model.state_dict(), 'shadow_' + args.shadow_dataset_name + '_' + args.shadow_backbone + '_' + str(
                        args.shadow_num_per_class) + 'best_model.pkl')
    else:
        for i in range(args.GNN_epochs):
            model.train()
            optimizer.zero_grad()
            out = model(train_data.x, train_data.mp_edge_index, args)
            loss = torch.nn.functional.cross_entropy(out, train_data.y)
            loss.backward()
            optimizer.step()
            _, acc = test_GNN(model, val_data, args)
            if acc > max_acc:
                max_acc = acc
                if mode == 'target':
                    torch.save(model.state_dict(), 'target_' + args.target_dataset_name + '_' + args.target_backbone + '_' + str(
                        args.target_num_per_class) + 'best_model.pkl')
                else:
                    torch.save(model.state_dict(), 'shadow_' + args.shadow_dataset_name + '_' + args.shadow_backbone + '_' + str(
                        args.shadow_num_per_class) + 'best_model.pkl')
    if mode == 'target':
        model.load_state_dict(torch.load('target_' + args.target_dataset_name + '_' + args.target_backbone + '_' + str(
            args.target_num_per_class) + 'best_model.pkl'))
    else:
        model.load_state_dict(torch.load('shadow_' + args.shadow_dataset_name + '_' + args.shadow_backbone + '_' + str(
            args.shadow_num_per_class) + 'best_model.pkl'))
    _, acc = test_GNN(model, test_data, args)

# 测试目标GNN和影子GNN
def test_GNN(model, test_data, args):
    model.eval()
    if args.GNN_batched == True:
        loader = NeighborSampler(edge_index = test_data.mp_edge_index, node_idx = test_data.infer_mask,
                                 sizes = [-1, -1], num_nodes = test_data.x.shape[0], batch_size = args.batch_size, shuffle = True)

        all_out = []
        all_loss = []
        for j, (batch_size, n_id, adjs) in enumerate(loader):
            adjs = [adj.to(args.device) for adj in adjs]
            out = model(test_data.x[n_id].to(args.device), adjs, args)
            loss = torch.nn.functional.cross_entropy(out, test_data.y[n_id[:batch_size]].to(args.device))
            all_out.append(out.cpu())
            all_loss.append(loss)

        all_out = torch.cat(all_out, dim=0)
        acc, f1_mi, f1_ma = evaluate(test_data.y[test_data.infer_mask].cpu(), all_out.cpu().argmax(dim=-1))
        return all_out, acc
    else:
        out = model(test_data.x, test_data.mp_edge_index, args)
        acc, f1_mi, f1_ma = evaluate(test_data.y[test_data.infer_mask].cpu(), out[test_data.infer_mask].cpu().argmax(dim=-1))
        out = out.cpu()
        return out[test_data.infer_mask].cpu(), acc

