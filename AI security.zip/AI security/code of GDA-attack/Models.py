import torch
from torch_geometric.nn.models.autoencoder import reset
from torch_geometric.nn import GAE, GCNConv, SAGEConv, GATConv
from torch_geometric.utils import negative_sampling, remove_self_loops, add_self_loops
import numpy as np
from torch_geometric.data import Data
from torch_geometric.loader import DataLoader

EPS = 1e-15
MAX_LOGSTD = 10

# 结构解码器
class InnerProductDecoder(torch.nn.Module):
    def forward(self, z, edge_index, sigmoid=True):
        value = (z[edge_index[0]] * z[edge_index[1]]).sum(dim=1)
        return torch.sigmoid(value) if sigmoid else value

    def forward_all(self, z, sigmoid=True):
        adj = torch.bmm(z, z.transpose(1,2))
        return torch.sigmoid(adj) if sigmoid else adj

class GAE(torch.nn.Module):
    def __init__(self, encoder, feats_decoder, graph_decoder=None):
        super().__init__()
        self.encoder = encoder
        self.graph_decoder = InnerProductDecoder() if graph_decoder is None else graph_decoder
        self.feats_decoder = feats_decoder
        GAE.reset_parameters(self)

    def reset_parameters(self):
        reset(self.encoder)
        reset(self.graph_decoder)
        reset(self.feats_decoder)

    def encode(self, *args, **kwargs):
        return self.encoder(*args, **kwargs)

# GDA图距离自编码器
class MIA_GAE(GAE):
    def __init__(self, encoder, feats_decoder, graph_decoder=None):
        super().__init__(encoder, feats_decoder, graph_decoder)

    def neg_sampling(self, all_edge_index, z, pos_edge_index):
        all_edge_index_tmp, _ = remove_self_loops(all_edge_index)
        all_edge_index_tmp, _ = add_self_loops(all_edge_index_tmp)
        neg_edge_index = negative_sampling(all_edge_index, z.size(0), pos_edge_index.size(1))
        return neg_edge_index


    def perturbed_graph(self, data, drop_prob):
        x_drop_mask = torch.rand(data.x.size(1)) < drop_prob
        perturbed_x = data.x.clone()
        perturbed_x[:, x_drop_mask] = 1 - data.x[:, x_drop_mask]

        # edge_drop_mask = torch.rand(data.mp_edge_index.size(1)) > drop_prob
        # perturbed_edge_index = data.mp_edge_index[:,edge_drop_mask]
        #
        # num_added_edges = int(drop_prob * data.edge_index.shape[1])
        # added_edges = torch.randint(0, data.x.shape[0], (2, num_added_edges))
        # perturbed_edge_index = torch.cat([perturbed_edge_index, added_edges], dim=1)
        # perturbed_edge_index = to_undirected(perturbed_edge_index)

        perturbed_edge_index = data.mp_edge_index

        perturbed_data = Data(x = perturbed_x, y = data.y, edge_index = data.edge_index, mp_edge_index = perturbed_edge_index)
        return perturbed_data

    def infoNCE_loss(self, z1, z2):
        f = lambda x: torch.exp(x / 0.05)

        def sim(z1, z2):
            z1 = torch.nn.functional.normalize(z1)
            z2 = torch.nn.functional.normalize(z2)
            return torch.mm(z1, z2.t())
        infonce_loss = -torch.log(f(sim(z1, z2)).diag() / (f(sim(z1, z1)).sum() + f(sim(z1, z2)).sum() - f(sim(z1, z1)).diag())).mean()
        print('infoNCE_loss:', infonce_loss)
        return infonce_loss

    def graph_recon_loss(self, z, pos_edge_index, all_edge_index):
        pos_loss = -torch.log(self.graph_decoder(z, pos_edge_index, sigmoid=True) + 1e-15).mean()
        neg_edge_index = self.neg_sampling(all_edge_index, z, pos_edge_index)
        neg_loss = -torch.log(1 - self.graph_decoder(z, neg_edge_index, sigmoid=True) + 1e-15).mean()
        return pos_loss + neg_loss

    def feats_recon_loss(self, z, x):
        return torch.nn.functional.mse_loss(x, self.feats_decoder(z))

    def recon_loss(self, x, pos_edge_index, all_edge_index):
        z = self.encode(x, pos_edge_index)
        graph_recon_loss = self.graph_recon_loss(z, pos_edge_index, all_edge_index)
        feats_recon_loss = self.feats_recon_loss(z, x)
        print('graph_recon_loss:',graph_recon_loss,'|feats_recon_loss:',feats_recon_loss)
        return graph_recon_loss + feats_recon_loss

    def graph_test(self, z, pos_edge_index, all_edge_index):
        from sklearn.metrics import average_precision_score, roc_auc_score

        neg_edge_index = self.neg_sampling(all_edge_index, z, pos_edge_index)
        pos_y = z.new_ones(pos_edge_index.size(1))
        neg_y = z.new_zeros(neg_edge_index.size(1))
        y = torch.cat([pos_y, neg_y], dim=0)

        pos_pred = self.graph_decoder(z, pos_edge_index, sigmoid=True)
        neg_pred = self.graph_decoder(z, neg_edge_index, sigmoid=True)
        pred = torch.cat([pos_pred, neg_pred], dim=0)

        y, pred = y.detach().cpu().numpy(), pred.detach().cpu().numpy()

        return roc_auc_score(y, pred), average_precision_score(y, pred)

    def feats_test(self, z, x):
        return torch.nn.functional.mse_loss(x, self.feats_decoder(z))

# GDA编码器
class GAE_GNNencoder(torch.nn.Module):
    def __init__(self, in_dim, hidden_dim, out_dim, backbone):
        super().__init__()
        if backbone == 'GCN':
            self.conv1 = GCNConv(in_dim, hidden_dim)
            self.conv2 = GCNConv(hidden_dim, out_dim)
        if backbone == 'GAT':
            self.conv1 = GATConv(in_dim, hidden_dim, heads = 1)
            self.conv2 = GATConv(1 * hidden_dim, out_dim, heads = 1)

    def forward(self, x, edge_index):
        h = torch.nn.functional.relu(self.conv1(x, edge_index))
        return self.conv2(h, edge_index)

# GDA属性解码器
class Featsdecoder(torch.nn.Module):
    def __init__(self, in_dim, hidden_dim, out_dim):
        super().__init__()
        self.decoder1 = torch.nn.Linear(in_dim, hidden_dim)
        self.decoder2 = torch.nn.Linear(hidden_dim, out_dim)

    def forward(self, x):
        h = torch.nn.functional.relu(self.decoder1(x))
        h = torch.sigmoid(self.decoder2(h))
        return h

# GNN
class GNN(torch.nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, backbone):
        super().__init__()
        self.layers = torch.nn.ModuleList()
        self.backbone = backbone
        if backbone == 'GCN':
            self.layers.append(GCNConv(input_dim, hidden_dim, normalize = True))
            self.layers.append(GCNConv(hidden_dim, output_dim, normalize = True))
        if backbone == 'GraphSAGE':
            self.layers.append(SAGEConv(input_dim, hidden_dim, normalize = True))
            self.layers.append(SAGEConv(hidden_dim, output_dim, normalize = True))
        if backbone == 'GAT':
            self.layers.append(GATConv(input_dim, hidden_dim, heads = 1))
            self.layers.append(GATConv(1 * hidden_dim, output_dim, heads = 1))

    def forward(self, x, adjs, args):
        if self.backbone == 'GraphSAGE' or self.backbone == 'GT':
            for i, (edge_index, _, size) in enumerate(adjs):
                x_target = x[:size[1]]
                x = self.layers[i]((x, x_target), edge_index)
                if i != self.num_layers - 1:
                    x = torch.nn.functional.relu(x)
                    x = torch.nn.functional.dropout(x, p = args.GNN_dropout)
        else:
            for i in range(len(self.layers)):
                x = self.layers[i](x, adjs)
                if i != len(self.layers) - 1:
                    x = torch.nn.functional.relu(x)
                    x = torch.nn.functional.dropout(x, p = args.GNN_dropout)
        return torch.nn.functional.softmax(x, dim = -1)


# GDA-attack攻击模型
class Adv_attack_model(torch.nn.Module):
    def __init__(self, feats_decoder, GNN, dim, args, edge_indexs = None, graph_decoder = None):
        super().__init__()
        self.graph_decoder = InnerProductDecoder() if graph_decoder is None else graph_decoder
        self.feats_decoder = feats_decoder
        self.GNN = GNN.to(args.device)
        self.dim = dim
        self.edge_indexs = edge_indexs
        self.args = args

    def forward(self, flatten_z, index):
        num = 0
        z = torch.reshape(flatten_z, (flatten_z.shape[0], flatten_z.shape[1] // self.dim, self.dim))
        recon_adj = self.graph_decoder.forward_all(z)
        recon_data = []
        result = []
        for k in range(flatten_z.shape[0]):
            num += 1
            recon_edge_index = [[],[]]
            recon_edge_weight = []
            for i in range(0, torch.div(self.args.data_n[index], self.args.GCNencoder_output_dim, rounding_mode='floor')):
                for j in range(i + 1, torch.div(self.args.data_n[index], self.args.GCNencoder_output_dim, rounding_mode='floor')):
                    if recon_adj[k][i][j] > 0.5:
                        recon_edge_index[0].append(i)
                        recon_edge_index[0].append(j)
                        recon_edge_index[1].append(j)
                        recon_edge_index[1].append(i)
                        if self.args.edge_weight:
                            recon_edge_weight.append(recon_adj[k][i][j])
                            recon_edge_weight.append(recon_adj[k][i][j])
            recon_edge_index = torch.from_numpy(np.array(recon_edge_index))
            recon_edge_weight = torch.from_numpy(np.array(recon_edge_weight))
            recon_x = self.feats_decoder(z[k])
            if self.args.norm == True:
                recon_x = torch.where(recon_x >= 0.5, 1.0, 0.0)
            if self.args.edge_weight:
                recon_data.append(Data(x = recon_x, edge_index = recon_edge_index.long(), edge_attr = recon_edge_weight).to(self.args.device))
            else:
                if self.edge_indexs == None:
                    recon_data.append(Data(x = recon_x, edge_index=recon_edge_index.long()).to(self.args.device))
                else:
                    recon_data.append(Data(x=recon_x, edge_index=self.edge_indexs[index]).to(self.args.device))
        loader = DataLoader(recon_data, batch_size = self.args.batch_size, shuffle=False)
        for data in loader:
            num += 1
            GNN_pred = self.GNN(data.x, data.edge_index, self.args)[::flatten_z.shape[1] // self.dim]
            result.append(GNN_pred)
        result = torch.cat(result, 0)
        return result, num

