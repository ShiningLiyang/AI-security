import os

os.environ["CUDA_VISIBLE_DEVICES"] = '6'
os.environ["CUDA_LAUNCH_BLOCKING"] = '1'
os.environ["TORCH_USE_CUDA_DSA"] = '1'
import torch
from Parser import parameter_parser
from Utils import data_split, k_hop_subgraph
from Training import train_GNN, test_GNN, train_MIA_GAE
from Models import GNN, Adv_attack_model, MIA_GAE, GAE_GNNencoder, Featsdecoder
from Attack import hop_skip_jump_attack, threshold_attack
import numpy as np


# GDA-attack流程
def adv_attack():

    args = parameter_parser()
    # print('haha', torch.cuda.is_available())
    args.device = torch.device('cuda')

    # 目标数据集、影子数据集获取
    target_train_data, target_val_data, target_test_data, target_data, shadow_train_data, shadow_val_data, shadow_test_data, shadow_data = data_split(args)

    target_GNN = GNN(target_train_data.x.shape[1], args.target_GNN_hidden_dim, target_train_data.y.max().item() + 1, args.target_backbone)
    shadow_GNN = GNN(shadow_train_data.x.shape[1], args.shadow_GNN_hidden_dim, shadow_train_data.y.max().item() + 1, args.shadow_backbone)

    target_GNN_path = os.path.join('target_' + args.target_dataset_name + '_' + args.target_backbone + '_' + str(
                        args.target_num_per_class) + 'best_model.pkl')
    shadow_GNN_path = os.path.join('shadow_' + args.shadow_dataset_name + '_' + args.shadow_backbone + '_' + str(
                        args.shadow_num_per_class) + 'best_model.pkl')

    # 目标GNN、影子GNN训练
    if os.path.exists(target_GNN_path):
        target_GNN.load_state_dict(torch.load('{}'.format(target_GNN_path)))
    else:
        train_GNN(target_GNN, target_train_data, target_val_data, target_test_data, args, 'target')

    if os.path.exists(shadow_GNN_path):
        shadow_GNN.load_state_dict(torch.load('{}'.format(shadow_GNN_path)))
    else:
        train_GNN(shadow_GNN, shadow_train_data, shadow_val_data, shadow_test_data, args, 'shadow')

    # 目标GNN后验概率、影子GNN后验概率
    target_in_pred, target_train_acc = test_GNN(target_GNN, target_train_data, args)
    target_out_pred, target_test_acc = test_GNN(target_GNN, target_test_data, args)
    print(target_train_acc, target_test_acc)

    shadow_in_pred, shadow_train_acc = test_GNN(shadow_GNN, shadow_train_data, args)
    shadow_out_pred, shadow_test_acc = test_GNN(shadow_GNN, shadow_test_data, args)
    print(shadow_train_acc, shadow_test_acc)

    # 目标GNN、影子GNN仅标签输出
    target_in_pred = target_in_pred.argmax(dim=-1)
    target_out_pred = target_out_pred.argmax(dim=-1)
    shadow_in_pred = shadow_in_pred.argmax(dim=-1)
    shadow_out_pred = shadow_out_pred.argmax(dim=-1)

    encoder = GAE_GNNencoder(shadow_train_data.x.shape[1], args.GNNencoder_hidden_dim, args.GNNencoder_output_dim, args.shadow_backbone)
    featsdecoder = Featsdecoder(args.GNNencoder_output_dim, args.Featsdecoder_hidden_dim, shadow_train_data.x.shape[1])
    GAE_model = MIA_GAE(encoder, featsdecoder)

    # GDA训练
    train_MIA_GAE(GAE_model, shadow_test_data, shadow_val_data, shadow_data, args)

    shadow_train_mask = torch.zeros(shadow_test_data.x.shape[0], dtype = torch.bool)
    for i in range(len(shadow_train_mask)):
        if shadow_test_data.infer_mask[i] != True:
            shadow_train_mask[i] = True

    # 获取每个节点k跳子图并封装为单独图
    shadow_train_sub_data, _ = k_hop_subgraph(shadow_test_data, torch.arange(0, shadow_test_data.x.shape[0])[
        shadow_train_mask].tolist(), args)

    shadow_test_sub_data, _ = k_hop_subgraph(shadow_test_data, torch.arange(0, shadow_test_data.x.shape[0])[shadow_test_data.infer_mask].tolist(), args)

    shadow_train_sub_data.extend(shadow_test_sub_data)
    shadow_attack_data = shadow_train_sub_data

    shadow_ground_truth = torch.cat((shadow_train_data.y[shadow_train_data.infer_mask], shadow_test_data.y[shadow_test_data.infer_mask]), dim = -1)
    shadow_pred_label = torch.cat((shadow_in_pred, shadow_out_pred), dim = -1)

    shadow_dist = torch.zeros(shadow_ground_truth.shape[0], dtype = torch.float)
    shadow_correct = shadow_ground_truth == shadow_pred_label

    shadow_member = torch.zeros(shadow_correct.shape[0], dtype = torch.int64)
    shadow_member[: shadow_train_data.infer_mask.sum()] = 1


    # 根据每个节点k跳子图获取GDA隐层表示用于扰动攻击
    max_dim = max([data.x.shape[0] * args.GNNencoder_output_dim for data in shadow_attack_data])
    shadow_hidden_data = torch.zeros((len(shadow_attack_data), max_dim), dtype = torch.float32).to(args.device)
    data_n = []
    edge_indexs = []
    for i in range(len(shadow_attack_data)):
        z = GAE_model.encode(shadow_attack_data[i].x.to(args.device), shadow_attack_data[i].edge_index.to(args.device))
        z = z.reshape(1, -1)
        shadow_hidden_data[i,:min(max_dim, z.shape[0] * z.shape[1])] = z[0,:min(max_dim, z.shape[0] * z.shape[1])]
        data_n.append(min(max_dim, z.shape[0] * z.shape[1]))
        edge_indexs.append(shadow_attack_data[i].edge_index)
    data_n = torch.from_numpy(np.array(data_n))
    args.data_n = data_n

    shadow_attack_model = Adv_attack_model(featsdecoder, shadow_GNN, args.GNNencoder_output_dim, args, edge_indexs)

    i = 0

    num = 0

    # 对每个节点的隐表示逐个进行基于对抗攻击的GDA-attack
    while i < len(shadow_attack_data):
        if i + args.batch_size < len(shadow_attack_data):
            batch_data = shadow_hidden_data[i: i + args.batch_size]
        else:
            batch_data = shadow_hidden_data[i:]

        dist, avg_num = hop_skip_jump_attack(shadow_attack_model, batch_data.to(args.device), args, i, clip_min=shadow_hidden_data.min(),
                                         clip_max=shadow_hidden_data.max(), max_num_evals = args.eval_num)


        shadow_dist[i: i + batch_data.shape[0]] = dist
        i += args.batch_size
        num += avg_num * batch_data.shape[0]

    for i in range(shadow_dist.shape[0]):
        if not shadow_correct[i]:
            shadow_dist[i] = 0

    shadow_max = -1
    torch.save(shadow_dist, "./" + args.shadow_dataset_name + "_" + str(args.shadow_num_per_class) + "_shadow_dist" + ".pt")
    for i in range(shadow_dist.shape[0]):
        if shadow_dist[i] != torch.tensor(float('inf')) and shadow_dist[i] > shadow_max:
            shadow_max = shadow_dist[i]
    shadow_dist = torch.where(shadow_dist < shadow_max, shadow_dist, shadow_max)


    threshold, attack_train_acc, auc = threshold_attack(shadow_dist, shadow_member)

    print(threshold)
    print(shadow_dist)
    print(shadow_member[:])
    print('attack_train_acc:',attack_train_acc)
    print('toal query num:', num / shadow_hidden_data.shape[0])
    print('auc:', auc)


    target_train_mask = torch.zeros(target_test_data.x.shape[0], dtype = torch.bool)
    for i in range(len(target_train_mask)):
        if target_test_data.infer_mask[i] != True:
            target_train_mask[i] = True

    target_train_sub_data, _ = k_hop_subgraph(target_test_data, torch.arange(0, target_test_data.x.shape[0])[
        target_train_mask].tolist(), args)

    target_test_sub_data, _ = k_hop_subgraph(target_test_data, torch.arange(0, target_test_data.x.shape[0])[target_test_data.infer_mask].tolist(), args)

    target_train_sub_data.extend(target_test_sub_data)
    target_attack_data = target_train_sub_data

    target_ground_truth = torch.cat((target_train_data.y[target_train_data.infer_mask], target_test_data.y[target_test_data.infer_mask]), dim = -1)
    target_pred_label = torch.cat((target_in_pred, target_out_pred), dim = -1)


    target_dist = torch.zeros(target_ground_truth.shape[0], dtype = torch.float)
    target_correct = target_ground_truth == target_pred_label

    target_member = torch.zeros(target_correct.shape[0], dtype = torch.int64)
    target_member[: target_train_data.infer_mask.sum()] = 1


    max_dim = max([data.x.shape[0] * args.GNNencoder_output_dim for data in target_attack_data])
    target_hidden_data = torch.zeros((len(target_attack_data), max_dim), dtype = torch.float32).to(args.device)
    data_n = []
    edge_indexs = []
    for i in range(len(target_attack_data)):
        z = GAE_model.encode(target_attack_data[i].x.to(args.device), target_attack_data[i].edge_index.to(args.device))
        z = z.reshape(1, -1)
        target_hidden_data[i,:min(max_dim, z.shape[0] * z.shape[1])] = z[0,:min(max_dim, z.shape[0] * z.shape[1])]
        data_n.append(min(max_dim, z.shape[0] * z.shape[1]))
        edge_indexs.append(target_attack_data[i].edge_index)
    data_n = torch.from_numpy(np.array(data_n))
    args.data_n = data_n

    target_attack_model = Adv_attack_model(featsdecoder, target_GNN, args.GNNencoder_output_dim, args, edge_indexs)

    i = 0

    num = 0

    while i < len(target_attack_data):
        if i + args.batch_size < len(target_attack_data):
            batch_data = target_hidden_data[i: i + args.batch_size]
        else:
            batch_data = target_hidden_data[i:]

        dist, avg_num = hop_skip_jump_attack(target_attack_model, batch_data.to(args.device), args, i, clip_min=shadow_hidden_data.min(),
                                         clip_max=shadow_hidden_data.max(), max_num_evals = args.eval_num)

        target_dist[i: i + batch_data.shape[0]] = dist
        i += args.batch_size
        num += avg_num * batch_data.shape[0]

    for i in range(target_dist.shape[0]):
        if not target_correct[i]:
            target_dist[i] = 0

    target_max = -1
    torch.save(target_dist, "./" + args.target_dataset_name + "_" + str(args.target_num_per_class) + "_target_dist" + ".pt")
    for i in range(target_dist.shape[0]):
        if target_dist[i] != torch.tensor(float('inf')) and target_dist[i] > target_max:
            target_max = target_dist[i]
    target_dist = torch.where(target_dist < shadow_max, target_dist, shadow_max)

    _, _, auc = threshold_attack(target_dist, target_member)

    target_pred = torch.where(target_dist < threshold, 0, 1)

    accuracy = torch.sum(target_pred == target_member).item() / len(target_pred)

    print('test_acc:', accuracy)
    print('auc:',auc)

    return auc

adv_attack()
