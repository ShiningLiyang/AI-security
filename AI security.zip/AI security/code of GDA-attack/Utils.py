import torch
import numpy as np
from torch_geometric.datasets import Planetoid, Amazon
import os
import random
from sklearn.metrics import f1_score
from torch_geometric.utils import to_undirected
from torch_geometric.data import Data


# 性能评估
def evaluate(label, y_pred):
    acc = y_pred.eq(label).sum().item() / y_pred.shape[0]
    f1_micro = f1_score(label, y_pred, average = 'micro')
    f1_macro = f1_score(label, y_pred, average = 'macro')
    return acc, f1_micro, f1_macro

# 加载数据
def load_data(dataset_name):
    if dataset_name == 'Cora' or dataset_name == 'CiteSeer' or dataset_name == 'PubMed':
        dataset = Planetoid(root='./Data', name='{}'.format(dataset_name))[0]
    elif dataset_name == 'Computers' or dataset_name == 'Photo':
        dataset = Amazon(root='./Data', name='{}'.format(dataset_name))[0]
    return dataset

# 数据切分，分为影子数据集和目标数据集
def data_split(args):
    ood = args.target_dataset_name == args.shadow_dataset_name
    if ood:
        dataset = load_data(args.target_dataset_name)
        target_dataset = shadow_dataset = dataset
        num_classes = dataset.y.max() + 1

        label_idx = dataset.y.numpy().tolist()

        if os.path.isfile("./" + args.target_dataset_name + "_target_train_idx" + "_" + str(args.target_num_per_class) + ".pt"):
            target_train_idx = torch.load("./" + args.target_dataset_name + "_target_train_idx" + "_" + str(args.target_num_per_class) + ".pt")
            target_val_idx = torch.load("./" + args.shadow_dataset_name + "_target_val_idx" + "_" + str(args.target_num_per_class) + ".pt")
            target_test_idx = torch.load("./" + args.target_dataset_name + "_target_test_idx" + "_" + str(args.target_num_per_class) + ".pt")

            shadow_train_idx = torch.load("./" + args.shadow_dataset_name + "_shadow_train_idx" + "_" + str(args.shadow_num_per_class) + ".pt")
            shadow_val_idx = torch.load("./" + args.target_dataset_name + "_shadow_val_idx" + "_" + str(args.shadow_num_per_class) + ".pt")
            shadow_test_idx = torch.load("./" + args.shadow_dataset_name + "_shadow_test_idx" + "_" + str(args.shadow_num_per_class) + ".pt")
        else:
            target_train_idx = []
            shadow_train_idx = []


            for c in range(num_classes):
                idx = (dataset.y == c).nonzero().view(-1)
                sample_train_idx = idx[torch.randperm(idx.size(0))]
                sample_target_train_idx = sample_train_idx[:args.target_num_per_class]
                target_train_idx.extend(sample_target_train_idx)
                sample_shadow_train_idx = sample_train_idx[
                                          args.target_num_per_class:args.target_num_per_class + args.shadow_num_per_class]
                shadow_train_idx.extend(sample_shadow_train_idx)

            target_train_idx = [i.item() for i in target_train_idx]
            shadow_train_idx = [i.item() for i in shadow_train_idx]

            torch.save(target_train_idx, "./" + args.target_dataset_name + "_target_train_idx" + "_" + str(args.target_num_per_class) + ".pt")
            torch.save(shadow_train_idx, "./" + args.shadow_dataset_name + "_shadow_train_idx" + "_" + str(args.shadow_num_per_class) + ".pt")


            others = [x for x in range(len(label_idx)) if x not in set(target_train_idx) and x not in set(shadow_train_idx)]
            target_val_idx = random.sample(others, args.target_val_num)
            shadow_val = [x for x in others if x not in set(target_val_idx)]
            shadow_val_idx = random.sample(shadow_val, args.shadow_val_num)
            target_test = [x for x in shadow_val if x not in set(shadow_val_idx)]
            target_test_idx = random.sample(target_test, args.target_test_num)
            shadow_test = [x for x in target_test if x not in set(target_test_idx)]
            shadow_test_idx = random.sample(shadow_test, args.shadow_test_num)

            torch.save(target_val_idx, "./" + args.target_dataset_name + "_target_val_idx" + "_" + str(args.target_num_per_class) + ".pt")
            torch.save(shadow_val_idx, "./" + args.shadow_dataset_name + "_shadow_val_idx" + "_" + str(args.shadow_num_per_class) + ".pt")
            torch.save(target_test_idx, "./" + args.target_dataset_name + "_target_test_idx" + "_" + str(args.target_num_per_class) + ".pt")
            torch.save(shadow_test_idx, "./" + args.shadow_dataset_name + "_shadow_test_idx" + "_" + str(args.shadow_num_per_class) + ".pt")

    else:
        target_dataset = load_data(args.target_dataset_name)
        target_num_classes = target_dataset.y.max() + 1
        target_label_idx = target_dataset.y.numpy().tolist()

        shadow_dataset = load_data(args.shadow_dataset_name)
        shadow_num_classes = shadow_dataset.y.max() + 1
        shadow_label_idx = shadow_dataset.y.numpy().tolist()

        if os.path.isfile("./" + args.target_dataset_name + "_target_train_idx" + "_" + str(args.target_num_per_class) + ".pt"):
            target_train_idx = torch.load("./" + args.target_dataset_name + "_target_train_idx" + "_" + str(args.target_num_per_class) + ".pt")
            target_val_idx = torch.load("./" + args.shadow_dataset_name + "_target_val_idx" + "_" + str(args.target_num_per_class) + ".pt")
            target_test_idx = torch.load("./" + args.target_dataset_name + "_target_test_idx" + "_" + str(args.target_num_per_class) + ".pt")
        else:
            target_train_idx = []

            for c in range(target_num_classes):
                idx = (target_dataset.y == c).nonzero().view(-1)
                sample_train_idx = idx[torch.randperm(idx.size(0))]
                sample_target_train_idx = sample_train_idx[:args.target_num_per_class]
                target_train_idx.extend(sample_target_train_idx)

            target_train_idx = [i.item() for i in target_train_idx]
            torch.save(target_train_idx, "./" + args.target_dataset_name + "_target_train_idx" + "_" + str(args.target_num_per_class) + ".pt")

            others = [x for x in range(len(target_label_idx)) if x not in set(target_train_idx)]
            print("done others")
            target_val_idx = random.sample(others, args.target_val_num)
            print("done target test")
            target_test = [x for x in others if x not in set(target_val_idx)]
            target_test_idx = random.sample(target_test, args.target_test_num)
            torch.save(target_val_idx, "./" + args.target_dataset_name + "_target_val_idx" + "_" + str(args.target_num_per_class) + ".pt")
            torch.save(target_test_idx, "./" + args.target_dataset_name + "_target_test_idx" + "_" + str(args.target_num_per_class) + ".pt")

        if os.path.isfile("./" + args.shadow_dataset_name + "_target_train_idx" + "_" + str(args.shadow_num_per_class) + ".pt"):
        # if False:
            shadow_train_idx = torch.load("./" + args.shadow_dataset_name + "_shadow_train_idx" + "_" + str(args.shadow_num_per_class) + ".pt")
            shadow_val_idx = torch.load("./" + args.shadow_dataset_name + "_shadow_val_idx" + "_" + str(args.shadow_num_per_class) + ".pt")
            shadow_test_idx = torch.load("./" + args.shadow_dataset_name + "_shadow_test_idx" + "_" + str(args.shadow_num_per_class) + ".pt")
        else:
            shadow_train_idx = []

            for c in range(shadow_num_classes):
                idx = (shadow_dataset.y == c).nonzero().view(-1)
                sample_train_idx = idx[torch.randperm(idx.size(0))]
                sample_shadow_train_idx = sample_train_idx[:args.shadow_num_per_class]
                shadow_train_idx.extend(sample_shadow_train_idx)

            shadow_train_idx = [i.item() for i in shadow_train_idx]
            torch.save(shadow_train_idx, "./" + args.shadow_dataset_name + "_shadow_train_idx" + "_" + str(args.shadow_num_per_class) + ".pt")

            others = [x for x in range(len(shadow_label_idx)) if x not in set(shadow_train_idx)]
            shadow_val_idx = random.sample(others, args.shadow_val_num)
            shadow_test = [x for x in others if x not in set(shadow_val_idx)]
            shadow_test_idx = random.sample(shadow_test, args.shadow_test_num)
            torch.save(shadow_val_idx, "./" + args.shadow_dataset_name + "_shadow_val_idx" + "_" + str(args.shadow_num_per_class) + ".pt")
            torch.save(shadow_test_idx, "./" + args.shadow_dataset_name + "_shadow_test_idx" + "_" + str(args.shadow_num_per_class) + ".pt")

    def inductive_setting(dataset, train_idx, val_idx, test_idx):
        train_mask = torch.zeros(dataset.x.shape[0], dtype = torch.bool)
        train_mask[train_idx] = True
        print(train_mask.sum())

        val_mask = torch.zeros(dataset.x.shape[0], dtype = torch.bool)
        val_mask[val_idx] = True

        test_mask = torch.zeros(dataset.x.shape[0], dtype = torch.bool)
        test_mask[test_idx] = True

        train_mappings = {train_idx[i]: i for i in range(len(train_idx))}
        print(train_mappings)

        val_mappings = {(sorted(train_idx + val_idx))[i]: i for i in range(len(train_idx + val_idx))}
        print(val_mappings)
        test_mappings = {(sorted(train_idx + test_idx))[i]: i for i in range(len(train_idx + test_idx))}

        train_edge_index = [[],[]]
        val_edge_index = [[],[]]
        val_recon_edge_index = [[],[]]
        test_edge_index = [[],[]]
        test_recon_edge_index = [[],[]]

        for i in range(len(dataset.edge_index[0])):
            src, tar = dataset.edge_index[0][i].item(), dataset.edge_index[1][i].item()
            if train_mask[src] and train_mask[tar]:
                train_edge_index[0].append(train_mappings[src])
                train_edge_index[1].append(train_mappings[tar])
                train_edge_index[0].append(train_mappings[tar])
                train_edge_index[1].append(train_mappings[src])
            elif (train_mask[src] or val_mask[src]) and (train_mask[tar] or val_mask[tar]):
                val_recon_edge_index[0].append(val_mappings[src])
                val_recon_edge_index[1].append(val_mappings[tar])
                val_recon_edge_index[0].append(val_mappings[tar])
                val_recon_edge_index[1].append(val_mappings[src])
            elif (train_mask[src] or test_mask[src]) and (train_mask[tar] or test_mask[tar]):
                test_recon_edge_index[0].append(test_mappings[src])
                test_recon_edge_index[1].append(test_mappings[tar])
                test_recon_edge_index[0].append(test_mappings[tar])
                test_recon_edge_index[1].append(test_mappings[src])
            if (train_mask[src] or val_mask[src]) and (train_mask[tar] or val_mask[tar]):
                val_edge_index[0].append(val_mappings[src])
                val_edge_index[1].append(val_mappings[tar])
                val_edge_index[0].append(val_mappings[tar])
                val_edge_index[1].append(val_mappings[src])
            if (train_mask[src] or test_mask[src]) and (train_mask[tar] or test_mask[tar]):
                test_edge_index[0].append(test_mappings[src])
                test_edge_index[1].append(test_mappings[tar])
                test_edge_index[0].append(test_mappings[tar])
                test_edge_index[1].append(test_mappings[src])


        train_edge_index = torch.from_numpy(np.array(train_edge_index))
        val_edge_index = torch.from_numpy(np.array(val_edge_index))
        val_recon_edge_index = torch.from_numpy(np.array(val_recon_edge_index))
        test_edge_index = torch.from_numpy(np.array(test_edge_index))
        test_recon_edge_index = torch.from_numpy(np.array(test_recon_edge_index))

        train_data = Data(x=dataset.x[train_mask], y=dataset.y[train_mask],
                          infer_mask=torch.ones(train_mask.sum(), dtype=torch.bool), edge_index=train_edge_index, mp_edge_index = train_edge_index)

        all_val_mask = torch.zeros(train_mask.sum() + val_mask.sum(), dtype=torch.bool)
        tmp_val_mask = train_mask | val_mask
        j = 0
        for i in range(tmp_val_mask.shape[0]):
            if train_mask[i] or val_mask[i]:
                if val_mask[i]:
                    all_val_mask[j] = True
                j += 1

        val_data = Data(x = dataset.x[tmp_val_mask], y = dataset.y[tmp_val_mask], infer_mask = all_val_mask, edge_index = val_recon_edge_index, mp_edge_index = val_edge_index)

        all_test_mask = torch.zeros(train_mask.sum() + test_mask.sum(), dtype=torch.bool)
        tmp_test_mask = train_mask | test_mask
        j = 0
        for i in range(tmp_test_mask.shape[0]):
            if train_mask[i] or test_mask[i]:
                if test_mask[i]:
                    all_test_mask[j] = True
                j += 1

        test_data = Data(x = dataset.x[tmp_test_mask], y = dataset.y[tmp_test_mask], infer_mask = all_test_mask, edge_index = test_recon_edge_index, mp_edge_index = test_edge_index)


        return train_data, val_data, test_data

    print(target_train_idx, target_val_idx, target_test_idx)
    target_train_data, target_val_data, target_test_data = inductive_setting(dataset, target_train_idx, target_val_idx,
                                                                             target_test_idx)
    shadow_train_data, shadow_val_data, shadow_test_data = inductive_setting(dataset, shadow_train_idx, shadow_val_idx,
                                                                             shadow_test_idx)

    return target_train_data, target_val_data, target_test_data, target_dataset, shadow_train_data, shadow_val_data, shadow_test_data, shadow_dataset

# 获取每个节点的k跳子图
def k_hop_subgraph(data, idx, args):
    sub_data = []
    edge_index = to_undirected(data.edge_index)
    for index in idx:
        neighbours = set([index])
        for _ in range(args.k):
            k_hop_neighbours = set()
            for neighbour in neighbours:
                k_hop_neighbours.update(edge_index[1][edge_index[0] == neighbour].tolist())
            neighbours.update(k_hop_neighbours)

        neighbours = list(neighbours)
        neighbours.remove(index)
        neighbours.insert(0, index)
        neighbours = torch.from_numpy(np.array(neighbours))

        mask = torch.isin(edge_index[0], neighbours).logical_and(torch.isin(edge_index[1], neighbours))

        subgraph_edge_index = edge_index[:, mask]

        mappings = {neighbours[i].item(): i for i in range(len(neighbours))}

        for i in range(subgraph_edge_index.size(1)):
            subgraph_edge_index[0][i] = mappings[subgraph_edge_index[0][i].item()]
            subgraph_edge_index[1][i] = mappings[subgraph_edge_index[1][i].item()]

        sub_data.append(Data(x = data.x[neighbours], y = data.y[neighbours], edge_index = subgraph_edge_index))
    return sub_data

