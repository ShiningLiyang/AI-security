import argparse

def parameter_parser():
    parser = argparse.ArgumentParser(description="Run .")
    parser.add_argument('--target_dataset_name',
                        type=str,
                        default='Cora',
                        help='Target dataset name.')
    parser.add_argument('--shadow_dataset_name',
                        type=str,
                        default='Cora',
                        help='Shadow dataset name.')

    parser.add_argument('--target_num_per_class',
                        type=int,
                        default='90',
                        help='Target num per class.')
    parser.add_argument('--shadow_num_per_class',
                        type=int,
                        default='90',
                        help='Shadow num per class.')

    parser.add_argument('--target_val_num',
                        type=int,
                        default='50',
                        help='Target val num.')
    parser.add_argument('--shadow_val_num',
                        type=int,
                        default='50',
                        help='Shadow val num.')

    parser.add_argument('--target_test_num',
                        type=int,
                        default='630',
                        help='Target test num.')
    parser.add_argument('--shadow_test_num',
                        type=int,
                        default='630',
                        help='Shadow test num.')

    parser.add_argument('--target_GNN_hidden_dim',
                        type=int,
                        default=16,
                        help='Hidden dimensions of Target Model.')
    parser.add_argument('--shadow_GNN_hidden_dim',
                        type=int,
                        default=16,
                        help='Hidden dimensions of Shadow Model.')

    parser.add_argument('--target_backbone',
                        type=str,
                        default='GCN',
                        help='Backbone of Target Model.')
    parser.add_argument('--shadow_backbone',
                        type=str,
                        default='GCN',
                        help='Backbone of Shadow Model.')

    parser.add_argument("--target_GNN_lr",
                        type=float,
                        default= 0.01,
                        help="Learning rate of target model. Default is 0.01.")
    parser.add_argument("--shadow_GNN_lr",
                        type=float,
                        default= 0.01,
                        help="Learning rate of shadow model. Default is 0.01.")

    parser.add_argument("--upper",
                        type=int,
                        default= 20000,
                        help="Initial query num.")

    parser.add_argument("--GNN_batched",
                        type=bool,
                        default= False)
    parser.add_argument("--GNN_epochs",
                        type=int,
                        default= 400,
                        help="GNN epochs.")
    parser.add_argument("--GNN_dropout",
                        type=int,
                        default= 0.,
                        help="GNN dropout.")



    parser.add_argument("--MIA_GAE_epochs",
                        type=int,
                        default = 400,
                        help="Number of training epochs.")

    parser.add_argument("--MIA_GAE_dropout",
                        type=float,
                        default= 0.,
                        help="Dropout parameter.")

    parser.add_argument("--MIA_GAE_lr",
                        type=float,
                        default= 0.01,
                        help="Learning rate.")

    parser.add_argument("--weight-decay",
                        type=float,
                        default= 0,
                        help="Weight Decay.")

    parser.add_argument('--iter',
                        type=int,
                        default = 20,
                        help='Iteration for HopSkipJump.')

    parser.add_argument('--batch-size',
                        type=int,
                        default = 512,
                        help='batchsize for train')

    parser.add_argument('--norm',
                        type=bool,
                        default = False,
                        help='Attributes normalization.')

    parser.add_argument('--GNNencoder_hidden_dim',
                        type=int,
                        default=32,
                        help='Hidden dimensions of GNN encoder.')
    parser.add_argument('--GNNencoder_output_dim',
                        type=int,
                        default=16,
                        help='Output dimensions of GNN encoder.')

    parser.add_argument('--Featsdecoder_hidden_dim',
                        type=int,
                        default=16,
                        help='Hidden dimensions of Featsdecoder.')

    parser.add_argument('--k',
                        type=int,
                        default=2,
                        help='K-hop.')


    parser.add_argument('--cuda',
                        type=bool,
                        default=True,
                        help='cuda settings.')


    parser.add_argument('--eval_num',
                        type=int,
                        default=10,
                        help='Eval num of HopSkipJump.')


    parser.add_argument('--attack_hidden_dim',
                        type=list,
                        default=[32],
                        help='Hidden dimensions of Attack Model.')

    return parser.parse_args()
